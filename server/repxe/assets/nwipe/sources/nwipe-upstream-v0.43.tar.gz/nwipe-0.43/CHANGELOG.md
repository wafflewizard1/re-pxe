RELEASE NOTES
=============
v0.43
-----------------------
# Notable New Features
 
## Introducing Hardware Sanitize (NIST 800-88 Purge)

We are excited to announce a major milestone in nwipe's data destruction capabilities: the long-awaited hardware sanitise feature.

As storage technology has evolved, traditional software-based overwriting has become less effective on modern flash memory due to wear-levelling algorithms and over-provisioning. With this release, nwipe introduces native support for hardware-level Sanitise commands, achieving a true "Purge" level of data destruction as defined by the NIST 800-88 guidelines. This makes nwipe fully equipped to handle modern SSD and NVMe drives securely and efficiently.

### Key Features
This release introduces a standalone Sanitize menu within the GUI, allowing you to trigger the drive's internal secure erasure mechanisms. Supported methods include:

- **Sanitize Block Erase**: Instructs the drive's controller to physically erase all blocks on the flash media, returning them to an empty state.
- **Cryptographic Erase** (Crypto Erase): For self-encrypting drives (SEDs), this command instantly sanitizes the drive by securely deleting the onboard media encryption key, rendering all encrypted user data permanently unreadable in a matter of seconds.
- **Sanitize Overwrite**: Instructs the drive to perform a hardware-level overwrite operation across all addressable and non addressable areas.

### Current Scope and Usage
In this initial rollout, Hardware Sanitize is implemented as a standalone interactive feature accessible exclusively through the nwipe GUI.

**Important Note for Automation**: Currently, Sanitize commands cannot be batched or used in conjunction with automated, multi-drive wiping commands such as autonuke. To Sanitize a drive in this release, you must manually select and execute the operation on individual drives via Nwipe's GUI.

### Drive Compatibility, Limitations & Historical Context
While Sanitize covers modern NIST 800-88 Purge requirements for newer drives, users should be aware of the following limitation regarding legacy hardware:

- No ATA Secure Erase Support: This release does not support the older ATA Secure Erase (or Enhanced Secure Erase) firmware commands. Consequently, nwipe does not currently handle "Freeze Lock" state management or wake-from-sleep workarounds required to unfreeze legacy drives for firmware erasure.

To understand drive support within the new Sanitize engine—and why older hardware remains unsupported—it helps to review how storage sanitation standards have progressed over time:

### 1. Legacy ATA Secure Erase (Pre-2012 Hardware)

- Origins: Introduced alongside the ATA-3 and ATA-4 specifications in the late 1990s via the SECURITY ERASE UNIT instruction set.
- Drive Types: PATA/IDE media, legacy SATA hard drives, and early first- or second-generation SATA SSDs manufactured before 2012.
- Why it became less relevant:
        - BIOS/UEFI "Freeze Locks": System firmware frequently applies a Freeze Lock status during bootup to safeguard drives against unauthorised wiping commands. Overcoming this restriction required cumbersome hardware power-cycling or manual hot-plugging routines.
        - SSD Inconsistencies: Early solid-state firmware implementations were notoriously inconsistent across manufacturers. Certain controllers merely cleared the LBA mapping table instead of purging physical cells, leaving over-provisioned blocks, wear-leveling pools, or onboard caches untouched.
- **nwipe Support Status: Not supported.** This tool does not execute legacy ATA Secure Erase instructions or perform freeze lock management.

### 2. Modern Hardware Sanitize (2012+ Hardware)
- Origins: Formalized within the ACS-2 (2011–2012) standards for SATA, SBC-3 for enterprise SAS, and NVMe 1.3 (2017) specifications.
- Drive Types: Modern SATA III SSDs, enterprise SAS hardware, and contemporary PCIe NVMe storage devices.
- Why Sanitize replaced Secure Erase:
        - NIST 800-88 Purge Guarantee: Engineered specifically to handle flash media complexities, guaranteeing physical erasure across hidden sectors, wear-leveling reserves, and internal caches.
        - Persistence & Security: When triggered, the drive controller places the hardware into an uninterrupted state that cannot be circumvented by system firmware, rejecting standard I/O requests until completion.
- **nwipe Support Status: Supported.**

### Hardware Support Summary
| Drive Type & Era | Specification | Low-Level Command Used | Status |
| ------------------------ | ------------------ | --------------------------------------- | --------- |
| Legacy Drives (Pre-2012) | ATA-3 to ATA-8 | ATA Secure Erase (0xF4) | Not Supported (Requires legacy firmware/freeze lock handling) Use hdparm |
| SATA SSDs / HDDs (Post-2012) | ATA/ATAPI ACS-2+ | ATA Sanitize (0xB4 Pass-Through) | Supported |
| NVMe SSDs (Post-2017) | NVMe 1.3+ | NVMe Admin Sanitize (0x84) | Supported|
| Enterprise SAS (Post-2012) | SCSI SBC-3 | SCSI Sanitize (0x94) | Planned / Untested (Requires SCSI CDB engine)

### Suggested Verification & Defense-in-Depth Procedures
Even though hardware Sanitize operations trigger firmware-level purging directly inside the controller, standalone software verification remains a critical practice. Hardware glitches, vendor-specific controller anomalies, or unhandled errors can occasionally result in a drive reporting complete sanitization despite retaining uncleared memory blocks.
To guarantee compliance and satisfy strict auditing standards, we suggest incorporating a multi-step validation sequence suited to your operational requirements:

### 1. Standard Validation: Post-Sanitize Read-Check
(Suggested for general hardware redeployment and compliance auditing)
Following any Hardware Sanitize operation (Block Erase, Cryptographic Erase, or Overwrite), execute a full Zero-Fill Verification pass across every host addressable sector (LBA).

- Why it matters: Reading back sectors verifies that the system receives consistent zero bytes () across user space, proving that at the very least, host accessible blocks have been zero'ed. 

<img width="1961" height="544" alt="Baseline verification workflow" src="https://github.com/user-attachments/assets/d0473bba-310c-4993-b017-1b5443040ebd" />

### 2. High-Assurance Multi-Pass Procedure
(Designed for high-security infrastructure, regulated environment storage, or untrusted drives)
For maximum data destruction, pair host software overwriting with native hardware sanitization to establish comprehensive protection covering both host-accessible LBAs and hidden sectors.

1. PRNG Overwrite Pass: Execute a software pattern write using pseudo-random data across all host-visible storage sectors.
2. PRNG Pattern Verification: Perform a read-check to ensure the random structure was applied correctly without bad block remapping interference.
3. Hardware Sanitize Command: Issue a native firmware Sanitize operation (Block Erase or Crypto Erase). This forces the drive to purge reserved areas inaccessible to host software—including over-provisioned space, wear-leveling pools, retired blocks, and controller caches.
4. Final Zero-Fill Verification: Complete a final read pass to confirm that every addressable sector returns zeros after sanitization.

<img width="1375" height="382" alt="High Assurance workflow" src="https://github.com/user-attachments/assets/1018b1e0-1187-4a20-8009-9c421839e1b0" />

- Why a PRNG write matters for stress testing data channels: While a standard PRNG write has been around for a very long time, since the 1980s/1990s? it is still an excellent way to stress test data channels & paths to help confirm the reliability of a drive as opposed to writing only zeros or ones. So if reliability testing as well as erasure is your concern a PRNG fill is another tool in the chest to achieve verification of reliability.

#### Isn't traditional writing bad for NVMe/SSDs? - Endurance & Wear Impact
Writing a full PRNG pass consumes 1 Drive Write (1 DW) (1 complete fill of the drive) of NAND endurance. For modern consumer SSDs, typically rated for 300–600 TBW (Terabytes Written) and enterprise SSDs (rated for 1–3+ DWPD (Drive Writes Per Day) over 5 years), a single diagnostic/erasure pass consumes a negligible fraction of total drive lifespan while providing high confidence in drive health.

There are no current ways that the host can verify that every over provisioned or non host accessible area has really been purged as by its very nature that memory is not accessible to the host system, i.e we have to trust the drive's firmware has done its job and is not hiding anything. Writing un-compressible  random data to the entire user addressable area so that the drive cannot use compression algorithms to avoid overwriting memory and has to store every single byte at least writes memory to the size of the disc. Followed by a sanitise operation to purge all areas and host accessible LBA verification this gives us additional confidence the drive has been successfully erased. Ultimately we still have to trust the drives firmware is operating correctly and bug free.

#### Sanitize (purge) selection on supported devices

<img width="846" height="327" alt="Screenshot_20260930_215022" src="https://github.com/user-attachments/assets/9c2dd0a5-2b71-4a56-aa18-0369ae8bdf46" />

#### Sanitize (purge) operations supported by the device - Block, Crypto, Overwrite.

<img width="846" height="327" alt="Screenshot_20260930_213454" src="https://github.com/user-attachments/assets/1c19e63b-5924-486f-85f6-f5cfa3334a7a" />


### Looking Ahead: The 0.44 Roadmap
We are already working hard on the next evolution of this feature. In the upcoming nwipe 0.44 release, Hardware Sanitize will be fully integrated into nwipe's traditional user interface.
This deep integration will allow you to select Sanitize as your primary wipe method directly from the main screen, bringing NIST 800-88 Purge capabilities to your automated workflows. With 0.44, you will be able to seamlessly autonuke an entire system using lightning-fast hardware Sanitize commands.

Thank you to our community for the ongoing feedback and testing that made this highly requested feature possible and a special thanks to @desertwitch for his valuable time in developing and implementing this feature. Very much appreciated.

----

## Introducing Real-Time Temperature Mapping Graph to Compliment the Speed Profile Graph on PDF reports.

### New Feature: Dual-Axis Thermal & Speed Profiling
We are pleased to introduce a major update to our PDF speed profile page, bringing drive temperature data directly alongside speed metrics.

#### Feature Overview
To provide a more comprehensive view of system health, we have integrated a drive temperature graph directly into the speed profile page on all PDF reports. This new graph sits beneath the existing speed profile, bound to the exact same Erasure duration X-axis.

#### Key Benefits
- Direct Visual Correlation: Stacking the speed & temperature graphs one above the other allows for immediate, vertical visual inspection. Users can now cross-reference drive performance with thermal behaviour at a glance.
- Instant Anomaly Diagnosis: Sudden drops or spikes or performance issues in erasure speed can be instantly mapped to thermal issues occurring at the exact same time, specifically to identify drives that may be operating outside the manufacturer's environmental specifications.
- Streamlined Debugging: Accelerates root-cause analysis.

<img width="1130" height="799" alt="Screenshot_20260930_001259" src="https://github.com/user-attachments/assets/a3cbc756-b6f4-4630-909e-0adc1427f407" />

Thanks @PartialVolume 


----

## Increase quantity of smart & non smart data on PDF reports

Nwipe now uses smartctl -x rather than -a, the extra sections returned typically now include:
- Device Statistics: A comprehensive log of the drive’s lifetime history. This covers absolute metrics like total bytes written/read (vital for assessing SSD lifespan), power cycles, flash write amplification factors, and hardware resets.
- SATA Physical Event Counters: Specific error logging for physical interface anomalies, such as CRC errors, link layer resets, and host-initiated bus resets. These logs are crucial for diagnosing faulty SATA cables or loose backplanes rather than a failing disk mechanism.
- SCT Temperature History: Instead of just showing the current temperature, -x prints a visual ASCII graph and structural timeline of the drive's internal temperature over time, including logging its historical minimum and maximum constraints.
- Extended Self-Test & Error Logs: Standard SMART -a outputs only the last few logged errors. -x pulls the fully extended error directory, catching long-term intermittent read/write faults or specific Logical Block Addresses (LBAs) that failed months prior.

If you prefer a simplified report without the smart data, let us know and with can supply a switch in nwipe's config to disable smart data in reports.

#### Key Data Comparison
| Feature / Data Returned | -a (--all) | -x (--xall) |
| ----------------------------------- | ----------- | ------------ |
| Basic Device Information (Model, Serial, Firmware version) |	Yes	| Yes |
| SMART Overall Health Status (PASSED / FAILED) | Yes | Yes |
| Vendor SMART Attributes Table (e.g., Reallocated Sector Count) | Yes	| Yes |
| Standard Error Log & Self-Test Logs | Yes | Yes |
| Extended Comprehensive Error Logs | No | Yes |
| Device Statistics (SATA/NVMe physical event counters) | No | Yes |
| SCT Temperature History & Summary | No | Yes |
| 48-bit ATA Command Support Logs | No | Yes |

Thanks @toreanderson #780 

----

# Fixes

miscellaneous: guard popen result before pclose in write_system_datetime #785 Thanks @SAY-5 


v0.42
-----------------------
## Notable New Features
### Added user created logo.jpg to PDFs
Allow the user to use their own logo in place of the nwipe embedded logo on the system and disc PDF certificates.

Thanks to @PartialVolume #767 

---

### Added optional blank pages between sections for duplex printing
Add intentionally blank pages as necessary ( --pdfduplex) to end a specific section within the system and disc PDF certificates, so that the new section always starts on a fresh sheet.

Thanks to @PartialVolume #761 

----

### Page numbering page n of n on system focused PDF
Add page n of n to the right hand footer section of the system focused PDF due to it's larger number of pages when wiping multiple discs simultaneously.

Thanks to @PartialVolume #766 

----

### Show disc I/O retries on single disk & system focused PDF certificates

Thanks to @PartialVolume #762 

----

### Show warning icon on single disc and system PDFs when a disc records retries indicating I/O errors**
Although the disc may have been successfully erased, a warning is now indicated on the PDF certificates to indicate the disc may not be in the best condition. If a warning icon is shown on the PDF,  checks the report for retries and consult the smart data to see what may be failing on the drive.

Thanks @PartialVolume #763 

----

### Updated the pdf generation library (PDFGen)
Updated nwipe's build in PDF generation library, specifically to include a new function pdf_add_line_pattern(). This function is required for the new speed profile graph in this release.

Thanks @PartialVolume #772 

----

### Added a speed profile page to both the single disk and system focused PDF certificates.
The speed profile page shows a graph of minimum, maximum and average speeds over the duration of the disk erasure. It is a good visual diagnostic tool to identify anomalies in disc performance. See https://github.com/martijnvanbrummelen/nwipe/discussions/775 for examples of speed profiles for both good and bad drives.

The example below shows a drive with read performance issues but despite the degradation of read performance the drive doesn't issue any I/O errors, no retries occur and the smart data provides a status of 'PASSED'. So the speed profile may show performance deviations that are not obvious when looking at the smart data or relying on I/O errors to identify a faulty drive.

Thanks @PartialVolume #773,#774,#776,#777
<img width="886" height="512" alt="image" src="https://github.com/user-attachments/assets/e337a58a-9149-4b31-a140-16c62a05a00e" />

----

### Added (R) Reverse, (S) Scatter suffixes to method as shown on PDF
When performing a reverse or scatter wipe, the PDF's will now show this by placing a (R) or (S) after the method type.

Thanks @PartialVolume #778

---

# Fixes
### Fixed mount-check to include and check for slave/parent devices in regards to [In-Use] feature.

Thanks to @Knogle #759 #757

---

### Fixed a segfault that occurs under a rare set of circumstances
Fixed a rare segfault that occurs when -v (verbose) logging is enabled and a system includes a /dev/mapper or LUKS device. Nwipe would incorrectly attempt to retrieve DCO information from the /dev/mapper or LUKS device. -v mode would normally only be used for developer use and debugging.

Thanks to @PartialVolume #760 

----

### Various typographical corrections
Thanks to @Extloga #765

----

### Updates to nwipe help (--help) and man page

Thanks to @PartialVolume #771 

----

### Fixed overlapping disk throughput on PDFs when four numeric characters are displayed e.g. 3100 MB/S

Thanks @PartialVolume #778 

# What's Changed (automated summary)
* Fixed a segfault due to a buffer overrun by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/760
* Add duplex printing option to PDFs --pdfduplex by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/761
* Fixed mount-check to include and check for slave/parent devices by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/759
* feat: Show disc retries on single and system PDFs by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/762
* Fix: Enable warning icon on retries on pdfs by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/763
* Fix: Various typographical corrections. by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/765
* Feat: Add page n of n on system report by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/766
* feat: Allow external logo.jpg for PDFs by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/767
* Update version to 0.41.1 in version.c by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/769
* Update both nwipe help & man page by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/771
* Updated the pdf generation library by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/772
* Initial creation of PDF graph function by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/773
* Add speed profile page creation by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/774
* Further work on speed profile by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/776
* Add speed profile 4 by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/777
* Miscellaneous, tidy up, direction on PDF by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/778

v0.41
-----------------------
## Notable New Features
* **SYSTEM PDF REPORT** "In response to the needs of organizations & individuals refurbishing and reselling hardware, nwipe has expanded its reporting capabilities. In addition to individual drive certificates, nwipe can now generate a single system-focused erasure certificate. This document consolidates the erasure status and SMART data of all installed drives and captures essential SMBIOS/DMI identifiers to ensure full auditability of the host, whether server, desktop or laptop." Note: The population of SMBIOS/DMI fields varies by manufacturer. While tier-one brands generally ensure high data integrity, some hardware vendors may provide incomplete or unpopulated data fields." Thanks @PartialVolume #717 #724 #752 #753 #754 Example: [nwipe_system_report (anonymized)](https://github.com/user-attachments/files/27805435/nwipe_system_report_2026-05-13-01-45-44_host-UUID-XXXXXXXXXXXXXXX_host-SN-XXXXXXXXXXXXXXX.pdf)


## What's Changed (auto generated list of all changes)
* Restructure PDF source files. We now have a separate source file for each type of PDF created. by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/717
* Major bugfixes & bad block/error handling by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/720
* Add optional non-fatal handling of block write errors in forward passes by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/685
* Merge pull request #717 from PartialVolume/restructure_PDF_source_files by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/723
* Initial work on system multi disc PDF, work in progress by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/724
* Update installation instructions in README.md by @TheSuperGiant in https://github.com/martijnvanbrummelen/nwipe/pull/726
* Reverse wiping, verification skip bad blocks & minor fixes by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/722
* PRNGs: Two new PRNGs + GUI Selection Screen by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/727
* CI unit testing for nwipe by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/725
* Tidy up display_help function by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/730
* Add the .clang-format-ignore file by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/731
* Bump minor version as a test of .clang-format-ignore by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/732
* Minor formatting fixes by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/733
* Some additional help info for display_help() by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/734
* Fix v0.40 regression (failing -std=c99, Fedora packaging) by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/736
* ci: add workflows for -std=c99/c11/c17 by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/737
* Added contribution guidelines, especially regarding the use of AI agents by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/739
* CI: Test `--directio` and `--cachedio` I/O modes by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/740
* I/O direction selection (--reverse) by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/735
* feat: introduce --force for in use devices by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/742
* Device geometry, scattered I/O, verification error paths by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/743
* fix(gui): do not select disabled devices by @desertwitch in https://github.com/martijnvanbrummelen/nwipe/pull/751
* System pdf by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/752
* Add system host UUID and serial number by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/753
* Add smbios dmi page to system pdf by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/754

## New Contributors
* @TheSuperGiant made their first contribution in https://github.com/martijnvanbrummelen/nwipe/pull/726

**Full Changelog**: https://github.com/martijnvanbrummelen/nwipe/compare/v0.40...v0.41

v0.40
-----------------------
includes the following changes:

## New Features and improved performance in V0.40
* Upon initialization, nwipe identifies and sets the most efficient Pseudo-Random Number Generator (PRNG) as the default, based on a real-time hardware performance test. Thanks to @knogle #698 #699 #700 #706
* AES-256-CTR PRNG that utilizes native [AES-NI instructions](https://en.wikipedia.org/wiki/AES_instruction_set) to significantly boost data-wiping throughput on compatible CPUs. Thanks @knogle #695 #660  #659
* Implemented a new wipe method, the  BMB21-2019 Chinese State Secrets Bureau standard Technical Requirement for Data Sanitization. Thanks @xicaixiaokeke #668
* Implemented Direct I/O with large buffers as the default wipe method, reducing write instructions and boosting throughput. This change cut wipe completion times by 5–10% in tests and significantly lowered CPU load—especially on high-density servers wiping 10+ drives simultaneously. Kernel cached I/O remains available via command-line switches. Thanks @knogle #683
* Added support for host UUID, serial number, and custom tags in PDF report headers. These options can be configured and toggled in the nwipe config menu ('c'), accessible from the nwipe drive selection screen and are saved to nwipe's config file, /etc/nwipe/nwipe.conf for persistent configuration between restarts." Thanks @PartialVolume #709
* Added a new GUI “device topology” view, opened with the 't' key from the device selection screen. Useful if you want to check which device controller, which HBA, etc. your drive is attached. This improves safety and usability on systems with multiple controllers by clearly showing the physical attachment path of each drive without changing wipe behaviour. Thanks @Knogle #697
* Enhanced the --exclude option to match devices by their underlying block device ID (major/minor), allowing persistent identifiers in /dev/disk/by-id/ and /dev/disk/by-path/ to be used safely. Legacy string-based matching is preserved. Thanks @Knogle #686
* The internal PRNGs are now seeded via getrandom(2) rather than through a long-lived file descriptor to /dev/urandom, to improve reliability. Thanks @Knogle #680

## Resolved issues
* fixed: To resolve issues with partition wipes, as opposed to whole disc wipes, nwipe now includes the device name in the PDF report filename. Previously, when wiping specific partitions (e.g., sudo nwipe /dev/sdc3 /dev/sd4 /dev/sd5) via the CLI, the absence of a disk model or serial number caused PDF filenames to conflict and overwrite each other. This update ensures unique filenames and prevents data loss when processing multiple partitions. Thanks @PartialVolume #676
* Add static linking libraries that are required by parted 3.6 @deamen #655
* fixed: some declaration changes to satisfy gcc 15 Thanks @Knogle & @xandris #663 #658
* Optimised that header code that generates the PDF reports. Thanks @PartialVolume #678
* fixed: respect no-blanking methods in --nogui mode. This fixes an issue where a default blanking pass was added to methods which do not support it when in --nogui mode. Existing GUI code overriding the option is never called in --nogui mode, Thanks @desertwitch #682
* fixed: sanitize device serial numbers and fix uninitialized/fallback handling. Thanks @Knogle #690
* fixed: Automatically create PDF report directory if missing and improve permission model Thanks @Knogle #693
* optimise: Validate autonuke and nogui for valid values and harden logic by not using assumptions in if statements for binary values and switching to case statements for value specific checks. Thanks @PartialVolume  #701
* fixed: Improve str_truncate to fix memory error detected in valgrind #702
* fixed: Require strict input of long form options, i.e no abbreviations allowed!. Command line option syntax as specifically described in `nwipe --help` and nwipe man page are only allowed. Corrects a 'feature' in GNU getopt_long().   Thanks @PartialVolume #705

v0.39
-----------------------
includes the following changes:
- Fix model name Endian for Sandisk-SunDisk drives by @PartialVolume in https://github.com/martijnvanbrummelen/nwipe/pull/643
- Implement Bruce Schneier 7-Pass wiping method by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/648
- Some cleanup in options.c, added missing xoroshiro256_prng argument i… by @Knogle in https://github.com/martijnvanbrummelen/nwipe/pull/651
- Removed EXPERIMENTAL! comments for ALFG and Xoroshiro. [#652](https://github.com/martijnvanbrummelen/nwipe/pull/652) Thanks @Knogle   
- Fix: some declaration changes to satisfy gcc 15. [#663](https://github.com/martijnvanbrummelen/nwipe/pull/663) Thanks @Knogle   

v0.38
-----------------------
includes the following changes:

- Fixes type error, relevant to i686 (32 bit) only. Fixes a compile error on some distros. [#588](https://github.com/martijnvanbrummelen/nwipe/pull/588) Thanks @Knogle 
- Added feature relevant to ShredOS only, the f key will toggle the font size, standard size to double size, has no action for other xorg/wayland distributions. The f key is available in the drive selection and progress screens only. Note that in earlier commits in this release the d key was programmed however this is now the f key to toggle font size. [#589](https://github.com/martijnvanbrummelen/nwipe/pull/589)  [#635](https://github.com/martijnvanbrummelen/nwipe/pull/635)  Thanks @PartialVolume 
- Fixes a issue where SAS drives always respond with hidden sectors = ???, i.e warning. This patch fixes the problem so that a SAS drive responds with hidden sectors = not applicable. A SATA drive connected to a SAS interface should still respond with yes or no subject to the interface passing HPA and DCO-identify commands. [#605](https://github.com/martijnvanbrummelen/nwipe/pull/605) Thanks @PartialVolume 
- On some distros, nwipe may not be able to find hdparm or smartctl even when they are installed. This is due to a symbolic link issue with the distro. The patch fixes this issue by adding a new search location when looking for hdparm and smartctl. The new search location is /usr/sbin/. Previously we searched /sbin/ and /usr/bin/ but /sbin is symbolically linked to /usr/sbin/ so just in case there was some issue with the symbolic link we also now search /usr/sbin/ [#606](https://github.com/martijnvanbrummelen/nwipe/pull/606) Thanks @PartialVolume 
- The hidden sector check for SAS drives has been disabled as it is believed that SAS drives do not support the SCSI commands to adjust the drives size as reported to the O.S. [#607](https://github.com/martijnvanbrummelen/nwipe/pull/607) Thanks @PartialVolume 
- Some USB adapters report the model name and serial number with the incorrect endian, so adjacent characters in the model name are swapped with each other. This patch detects and fixes model names for Hitachi, Toshiba, WDC Western Digital Corporation and Seagate/ST drives. Mainly some older adapters and drive interfaces might have this issue. [#630](https://github.com/martijnvanbrummelen/nwipe/pull/630) Thanks @PartialVolume 
- Fixes the `s shift s bug` as reported here https://github.com/PartialVolume/shredos.x86_64/issues/301 To summarize, if no drives are selected and then the user presses s (lower case) a warning appears indicating that the user should press S (upper case) to start the wipe. This warning appears for about 3 seconds but during this time if the user presses S (upper case) nwipe would immediately complete, having wiped no drives and requesting the user to press the spacebar to exit. The is incorrect behaviour.
The bug doesn't appear if the user pressed S after the 3 seconds elapsed and the warning message disappeared. This patch fixes this so that it does not exit but displays the warning for 3 seconds and then waits for input. [#636](https://github.com/martijnvanbrummelen/nwipe/pull/636)

v0.37
-----------------------
includes the following changes:

- Added the XORoshiro-256 pseudo random number generator (PRNG). Thanks to Fabian Druschke @knogle [#555](https://github.com/martijnvanbrummelen/nwipe/pull/555)
- Added  the Lagged Fibonacci PRNG generator. Thanks again to Fabian Druschke @knogle [#556](https://github.com/martijnvanbrummelen/nwipe/pull/556)
- Added missing help for HMG IS5 enhanced. Thanks to @AndCycle [#569](https://github.com/martijnvanbrummelen/nwipe/pull/569)
- Changed the default method from "DOD Short" to "prng stream", using the XORoshiro-256 prng
- Fixed an issue in configure.ac which was producing an error while running `./configure`,  mentioning libconfig, however the presence of libconfig had already been checked for, earlier in configure.ac. Although this error did not cause `./configure` to abort prematurely and therefore make would build the source correctly, it did cause a issue for inclusion into Debian Sid. Thanks to @Polynomial-C [#574](https://github.com/martijnvanbrummelen/nwipe/pull/574)
- Minor change to nwipe's man page filename, nwipe.1 to nwipe.8 to fix a Debian warning. [#577](https://github.com/martijnvanbrummelen/nwipe/pull/577)

v0.36
-----------------------
- Added the abbreviation MMC for mmcblk devices such as SD and microSD cards and some low budget laptops. [#526](https://github.com/martijnvanbrummelen/nwipe/pull/526)
- Fixed some serial numbers that were displaying garbage. [#527](https://github.com/martijnvanbrummelen/nwipe/pull/527)
- Fixed auto power off and nowait when the screen has been blanked by the user. [#529](https://github.com/martijnvanbrummelen/nwipe/pull/529)
- Fixed nwipe not auto exiting on completion when in non gui mode. [#531](https://github.com/martijnvanbrummelen/nwipe/pull/531)
- Fixed smart page titles so they have a consistent format with page 1 in the PDF report. [#532](https://github.com/martijnvanbrummelen/nwipe/pull/532)
- Fixed some of the config help messages that displayed incorrect information. [#533](https://github.com/martijnvanbrummelen/nwipe/pull/533)
- Inserted a space between temperature and model. [#534](https://github.com/martijnvanbrummelen/nwipe/pull/534)
- Fixed incorrect footer on return to organisation/customer preview screen. [#535](https://github.com/martijnvanbrummelen/nwipe/pull/535)
- Made footer completion message more informative. [#538](https://github.com/martijnvanbrummelen/nwipe/pull/538)
- Fixed hidden sector detection for devices with logical/physical size of 4096/4096. [#543](https://github.com/martijnvanbrummelen/nwipe/pull/543) [#546](https://github.com/martijnvanbrummelen/nwipe/pull/546)
- Fixed some strcpy compiler warnings. [#548](https://github.com/martijnvanbrummelen/nwipe/pull/548)

v0.35
-----------------------
- Nwipe will now optionally create a multi-page PDF certificate that shows details of a specific discs erasure. The first page forms the certificate of erasure and subsequent pages show the drives smart data. Two related options have been added to nwipe's command line options -P, --PDFreportpath=PATH Path to write PDF reports to. Default is "." If set to "noPDF" no PDF reports are written. From the drive selection screen you can now press 'c' for config. This takes you to the configuration screen where you can select various PDF certificate related options such as enabling PDF, entering customer or company data for entry onto the certificate and enabling a preview of customer/company info prior to the drive selection screen starting.
- Nwipe now supports HPA/DCO detection, aka hidden sector detection. This is where the drive has been configured to report a smaller size to the operating system (O.S.) than it actually is. The HPA/DCO status is reported on the main drive selection screen as [HS? N/A] for drive that does not support HPA/DCO such as NvMe. [HS? YES] for a drive that is reporting a size smaller than it actually is, i.e has hidden sectors and [HS? NO] where the drive is reporting it's actual size correctly to the O.S. And finally [HS? ???] where nwipe cannot determine the HPA/DCO status as the drive is not responding to the ATA commands used to detect HPA/DCO. This might be because the drive does not support HPA/DCO or the interface adapter does not support ATA passthrough as is the case with a lot of the USB adapters on the market, but not all USB adapters. Nwipe does not currently allow removal of the HPA/DCO so you will still need to use hdparm to reset the drive so it reports its correct size before using nwipe to wipe the drive. HPA/DCO reset may be added in the next version. Thanks to @mdcato for the help testing the code and HPA/DCO results as displayed in the report.
- This bug only applies to ones wipe and one or zero's verification. A very rare occurrence of a incorrect percentage on completion. The actual wipe was completed correctly it was just that the percentage calculation was wrong. [#459](https://github.com/martijnvanbrummelen/nwipe/pull/459)
- Nwipe now supports a configuration file /etc/nwipe/nwipe.conf. Currently it supports settings related to the PDF certificate but more options will be added in the future.
- If you are running nwipe within the KDE konsole terminal and you resize the window by pulling on the corners, occasionally nwipe will exit with the error message: "GUI.c,nwipe_gui_select(), loop runaway, did you close the terminal without exiting nwipe? Initiating shutdown now" The loop runaway detection has been made less sensitive, i.e 32 iterations per second of the GUI update can now be completed before a loop runaway is detected. previously it was 8. In practise when sizing the konsole window, anywhere between 1 and 17 iterations will occur. [#467](https://github.com/martijnvanbrummelen/nwipe/pull/467)
- Nwipe now provides better temperature support for SAS drives. Thanks to @ggruber for all the code and testing he contributed.
- Disc sizes are now shown differently to provide more information about their size. For instance a 1.2TB drive was shown as 1TB, now it is shown as 1200GB. Thanks to @ggruber for his code contribution.
- Interface/bustype type was reported as UNK for SAS drives, now reported correctly as SAS. Thanks to @ggruber for his code contribution.
- Interface/bustype type has been enhanced to show SAS-SSD when a SSD drive is present. Thanks to @ggruber for his code contribution.
- Nwipe's temperature retrieval code has been placed in it's own thread. This was done because it was found that any delays in obtaining the temperature resulted in a momentary freeze in the GUI wipe screen updating it's stats. This wasn't noticeable if you were erasing a small number of drives but become apparent when wiping ten or twenty drives simultaneously.

v0.34
-----------------------
- Fix a compiler warning -Wformat-zero-length string 

v0.33
-----------------------
- Fixes a slight screen corruption on 80 column display. When highlighting the verify ones option the first two digits of DoD 5220.20-M disappear. This patch fixes that issue.@PartialVolume [#348](https://github.com/martijnvanbrummelen/nwipe/pull/348)
- For some controllers/drivers the readlink method of obtaining the bus type for GUI display does not work. If we haven't already resolved the bus type, we then also check smartctl for the transport protocol for SAS. @PartialVolume [#350](https://github.com/martijnvanbrummelen/nwipe/pull/350)
- Check smartctl for unresolved bus types SATA  @PartialVolume [#358](https://github.com/martijnvanbrummelen/nwipe/pull/358)
- Changed message from (No ATA pass-thru) to (S/N: unknown) as the reason the serial number is unknown is because there is no ATA pass-through for the chipset being used by the USB to SATA adapter, basically we are making the message more meaningful for the end user rather than for the engineer/programmer that may understand the previous terminology used. @PartialVolume @Firminator [#356](https://github.com/martijnvanbrummelen/nwipe/pull/356) 
- Add drive temperature monitoring and display temperature in degrees Celsius in the GUI. Requires the kernel drivetemp module and makes use of the hwmon sub system in the kernel to extract drive temperatures. Nwipe will automatically load the drivetemp module if it's available. @PartialVolume [#360](https://github.com/martijnvanbrummelen/nwipe/pull/360) [#361](https://github.com/martijnvanbrummelen/nwipe/pull/361) [#364](https://github.com/martijnvanbrummelen/nwipe/pull/364)
- Remove /dev/ from gui for long device names. This fixes column alignment issues in the gui with nvme drives i.e. nvme0n1 etc. If the drive name including path exceeds 8 characters the /dev/ is removed and prefixed with spaces to a total max length of 8 characters. @PartialVolume [#365](https://github.com/martijnvanbrummelen/nwipe/pull/365)
- Add -q --quiet option - anonymize serial numbers and SMBIOS-DMI data. This anonymizes serial numbers and related identifiable information for drives and hardware but does not remove model information in both the GUI and the log displayed by stdout at the end of a wipe and also in the log file if enabled in options. This feature is useful for uploading logs when submitting bug reports. @PartialVolume [#366](https://github.com/martijnvanbrummelen/nwipe/pull/366) [#367](https://github.com/martijnvanbrummelen/nwipe/pull/367) [#371](https://github.com/martijnvanbrummelen/nwipe/pull/371) [#379](https://github.com/martijnvanbrummelen/nwipe/pull/379) [#383](https://github.com/martijnvanbrummelen/nwipe/pull/383)
- Fixes a intermittent FAILED message that is displayed in the summary table when the message should have been UABORTED. The incorrect FAILED message only occurred when using control-C to abort a wipe. @PartialVolume [#373](https://github.com/martijnvanbrummelen/nwipe/pull/373)
- When many verification or pass errors are detected the status line can wrap on a 80 column display. This patch makes the error message more succinct which will free up about 10 characters & prevents the line wrapping. @PartialVolume [#374](https://github.com/martijnvanbrummelen/nwipe/pull/374)
- Fixes a problem that occurs with a unresponsive drive that causes the ETA to grow to an enormous value. We now do not calculate an individual drives ETA  when the throughput of the drive is zero so avoiding the overall ETA being incorrect for drives that are working correctly when multiple drives are being simultaneously wiped. While a individual drives ETA is calculated it is not displayed but only used to determine the overall ETA when all drives have completed. @PartialVolume [#375](https://github.com/martijnvanbrummelen/nwipe/pull/375)
- Add temperature monitoring and display with NVMe drives. @PartialVolume [#377](https://github.com/martijnvanbrummelen/nwipe/pull/377) [#380](https://github.com/martijnvanbrummelen/nwipe/pull/380) [#381](https://github.com/martijnvanbrummelen/nwipe/pull/381)
- When one of the two verify only methods are selected change the drive selected text from WIPE to VRFY to indicate the drive is not being wiped, but is only being verified. @PartialVolume [#378](https://github.com/martijnvanbrummelen/nwipe/pull/378) 
- Fixes a incorrect sector, block and device sizes in 32 bit builds only as displayed in the nwipe log. This problem had no affect on the wipe as the issue was caused by a incorrect format specifier that affected the log text only. @PartialVolume [#387](https://github.com/martijnvanbrummelen/nwipe/pull/387) [#388](https://github.com/martijnvanbrummelen/nwipe/pull/388) 
- Fixes a issue where temperatures may not have been available on Debian systems due to the location of modprobe. Particularly relevant to Debian which when logged in as root doesn't put /sbin in the $PATH environment setting. This issue was not necessarily relevant for Linux distros based on Debian, for instance, Ubuntu where nwipe would have found the modprobe command. @PartialVolume [#390](https://github.com/martijnvanbrummelen/nwipe/pull/390) [#391](https://github.com/martijnvanbrummelen/nwipe/pull/391) 
- Improve wipe thread cancellation error checking. @PartialVolume [#392](https://github.com/martijnvanbrummelen/nwipe/pull/392)
- Improve GUI thread messaging if a pthread_join fails. @PartialVolume [#393](https://github.com/martijnvanbrummelen/nwipe/pull/393)
- Fixed a missing serial number on SAS drive.@PartialVolume [#394](https://github.com/martijnvanbrummelen/nwipe/pull/394) 
- Added ISAAC-64 for 64 bit systems. Thanks @chkboom [#398](https://github.com/martijnvanbrummelen/nwipe/pull/398) [#401](https://github.com/martijnvanbrummelen/nwipe/pull/401) 
- Fixes a problem with the Gutmann wipe where the random passes at the beginning and end were being re-arranged when only the inner passes should be rearranged. Thanks @chkboom [#399](https://github.com/martijnvanbrummelen/nwipe/pull/399)
- Fixes an obscure incorrect summary table status, while the log text correctly reports the failure. If the drive becomes non responsive during the wipe, the MB/s throughput will slowly drop towards 0MB/s and will display a FAILURE -1 error. The logs will correctly display errors and nwipe's return status will be non zero, however the summary table may display erased rather than FAILURE, this is because
the wipe thread exited prematurely without setting the pass error. This fixes the error by checking the context's result status, i.e non zero on failure and if pass equals zero it makes pass equal to one. This is then picked up by the summary table log code which then marks the status
correctly as FAILURE in the summary table. @PartialVolume [#400](https://github.com/martijnvanbrummelen/nwipe/pull/400)
- Fixes a spurious message on abort before wipe.This patch fixes a minor display issue that occurs when a user aborts a wipe before a wipe has started. It only occurs if the user had selected one or more drives for wipe and then aborted before starting the wipe. The spurious message only occurs in a virtual terminal, i.e. /dev/tty1, /dev/tty2, /dev/console It does not occur in terminal applications such as konsole, xterm, terminator etc. The spurious message that appears in the main window, states that "/dev/sdxyz 100% complete" along with garbage values in the statistics window. The message appears for a fraction of a second before being replaced with the textual log information that correctly states that the user aborted and no wipe was started. Basically the gui status information update function tries to update the data when the wipe hasn't even started. The fix is to only update the statistics information only if a wipe has started by checking the 'global_wipe_status' value which indicates whether any wipe started. '1' indicates that a wipe has started, else '0' if no wipe has started. @PartialVolume [#406](https://github.com/martijnvanbrummelen/nwipe/pull/406) 
- Fixes temperature update in drive selection window. This fixes a problem where the drive temperature is not updated
automatically in only the drive selection window. The temperature is however updated correctly every 60 seconds during a wipe in the wipe status window. This bug would probably never be noticed by most people as usually the drive temperature changes slowly and only rises once a wipe has started. The only time I imagine it would have been noticed would have been if the drive temperature was already high and you were trying to reduce the temperature by cooling before starting a wipe. This has now been corrected so that the temperature in the drive
selection window is updated every 60 seconds. @PartialVolume [#407](https://github.com/martijnvanbrummelen/nwipe/pull/407) 
- Fixes a zombie nwipe process running at 100% CPU on one core but only on a Konsole based terminal. This only occurred when the Konsole terminal is exited while nwipe is sitting at the drive selection screen but nwipe did not exit when the konsole terminal was closed. If nwipe is exited normally on completion of a wipe or aborted by using control C then this problem would not be seen. Also occurs during a wipe if the konsole terminal is closed without exiting nwipe first, again only on Konsole based terminals. @PartialVolume [#408](https://github.com/martijnvanbrummelen/nwipe/pull/408) [#409](https://github.com/martijnvanbrummelen/nwipe/pull/409) 
- Fixes a obscure segfault when --logfile option used with a non writable directory. @PartialVolume [#410](https://github.com/martijnvanbrummelen/nwipe/pull/410) 

v0.32
-----------------------
- Add ones (0xFF) wipe to the methods. Renamed Zero Fill to Fill with Zeros and the new ones wipe, is called Fill with Ones.
- Add ones verication to the methods. Renamed Verify Blank to Verify Zeros (0x00) and the new verification is called Verify Ones (0xFF).
- Move method information from below the list of methods to the right of the method list. This allows better use of the screen space by allowing more methods to be added to the list, especially relevant to nwipe running as a standalone application on small distros such as shredos 2020 in frame buffer mode.
- Removed the old DBAN syslinux.cfg configuration hints as not relevant to nwipe. See nwipe --help or man nwipe for command line options.
- Add fdatasync errors to the error summary table.
- During a wipe, you can now toggle between dark screen, blank screen and default blue screen by repeatedly pressing the b key. Dark screen, which is grey text on black background has been introduced to prevent TFT/LCD image persistence on monitors that are sensitive to that issue.

v0.31
-----------------------
- Blanking disabled in GUI for OPS2 (mandatory requirement of standard). [#326](https://github.com/martijnvanbrummelen/nwipe/pull/326)
- Total bytes written/read for ALL passes or verifications are now logged. [#326](https://github.com/martijnvanbrummelen/nwipe/pull/326)
- Final blanking being enabled is no longer required for verification passes. GUI Fix. [#326](https://github.com/martijnvanbrummelen/nwipe/pull/326)
- Add a summary table to the log that shows totals for pass & verification errors. [#325](https://github.com/martijnvanbrummelen/nwipe/pull/325)
- Fix the missing 'Verifying' message on final blanking. [#324](https://github.com/martijnvanbrummelen/nwipe/pull/324)
- Fix prng selection always using mersenne irrespective of whatever prng the user selected. [#323](https://github.com/martijnvanbrummelen/nwipe/pull/323)
- Fix a non functional Isaac prng. (May have never worked even in DBAN/dwipe 2.3.0). [#322](https://github.com/martijnvanbrummelen/nwipe/pull/322)
- Log whether the prng produces a stream, if not log failure message. [#321](https://github.com/martijnvanbrummelen/nwipe/pull/321)
- Log the specific prng that is initialised. [#320](https://github.com/martijnvanbrummelen/nwipe/pull/320)
- Log selection details to the log. [#319](https://github.com/martijnvanbrummelen/nwipe/pull/319)
- Improve log messaging. [#317](https://github.com/martijnvanbrummelen/nwipe/pull/317)
- Fix auto shutdown option for some distros. [#315](https://github.com/martijnvanbrummelen/nwipe/pull/315)
- Fix build for musl. [#301](https://github.com/martijnvanbrummelen/nwipe/pull/301)
- Fixes to summary table & fix final status message. [311](https://github.com/martijnvanbrummelen/nwipe/pull/311/commits/12063ad9549860cd625cb91d047bd304217a9ebf)
- Updates to --help options [#309](https://github.com/martijnvanbrummelen/nwipe/pull/309/commits/69c9d7d6c5a091c58b3e747078d0022ccdd95a99)
- Updates to manpage. [#300](https://github.com/martijnvanbrummelen/nwipe/commit/7cc1a68a89236c4b501dde9149be82c208defccd)

v0.30
-----------------------
- Add auto power off option on completion of wipe ( --autopoweroff ) (Thanks PartialVolume)
- Fixed --nowait option that wasn't working. (Thanks PartialVolume)
- Add verbose option. -v, --verbose.
- Add a spinner to the GUI for each drive being wiped. When nwipe is syncing the percentage completion pauses, having a spinner gives a clear indication that the wipe is still running. Each devices spinner disappears on completion of a given devices wipe. (Thanks PartialVolume)
- Make log messages, especially the ones with the tag 'notice' succinct and less than 80 characters including the timestamp. This is of more importance when nwipe is used on a 80x30 terminal (ALT-F2, Shredos etc) but generally makes the logs more readable. While doing this all information was still retained. (Thanks PartialVolume)
- Add a summary table to the log that shows each drives status, i.e. erased or failed, throughput, duration of wipe, model, serial no etc. In particular it benefits those that wipe many drives simultaneously in rack servers. At a glance any failed drives can be seen without having to browse back through the log. (Thanks PartialVolume)
- Add ETA to --nogui wipes status when SIGUSR1 (kill -s USR1 (nwipes PID) is issued on the command line.
- Fixed misleading throughput calculation. Throughput now shows average throughput calculated from start of wipe.
- Fixed system info not being displayed in Debian Sid. [#229](https://github.com/martijnvanbrummelen/nwipe/issues/229) (Thanks PartialVolume)
- Add serial number display for USB to IDE/SATA adapters. This only works if the USB to IDE/SATA adapter supports ATA pass through. See [#149](https://github.com/martijnvanbrummelen/nwipe/issues/149) for further details (Thanks PartialVolume)
- Fixed disk capacity nomenclature, width and padding on drive selection screen. See [#237](https://github.com/martijnvanbrummelen/nwipe/issues/237) (Thanks PartialVolume)
- Add bus type, ATA or USB, amongst others to drive selection and wipe windows. (Thanks PartialVolume)
- Add --nousb option. If you use the option --nousb, all USB devices will be ignored. They won't show up in the GUI and they won't be wiped if you use the --nogui --autonuke command. They will even be ignored if you specifically name them on the command line.
- Miscellaneous GUI fixes, throughput display format, percentage display format to improve column alignment when wiping multiple discs. (Thanks PartialVolume)
- Improve visibility of failure messages with red text on white background. (Thanks PartialVolume)
- Add NVME and VIRT (loop etc) devices to device type table for display in GUI and logs. NVME devices now show up as NVME devices rather than UNK (Thanks PartialVolume)
- Fixed very obscure segmentation fault going back to at least 0.24 in drive selection window when resizing terminal vertical axis while drive focus symbol '>' is pointing to the last drive of a multi drive selection window. See [#248](https://github.com/martijnvanbrummelen/nwipe/pull/248) for further details (Thanks PartialVolume)
- Warn the user if they are incorrectly typing a lower case s to start a wipe, when they should be typing a capital S [#262](https://github.com/martijnvanbrummelen/nwipe/issues/262) (Thanks PartialVolume)
- Warn the user if they are typing capital S in order to start a wipe but haven't yet selected any drives for wiping [#261](https://github.com/martijnvanbrummelen/nwipe/issues/261) (Thanks PartialVolume)
- Add ctrl A that toggles drive selection, all drives selected for wipe or all drives deselected. [#266](https://github.com/martijnvanbrummelen/nwipe/issues/266)
- Fixed compilation issue with NixOS with broken musl libc error due to missing header [#275](https://github.com/martijnvanbrummelen/nwipe/issues/275)
- Fixed status bar message showing incorrect information [#287](https://github.com/martijnvanbrummelen/nwipe/issues/287)
- Right Justify log labels to maintain column alignment [#280](https://github.com/martijnvanbrummelen/nwipe/issues/280)
- Added nwipe version & OS info to log [#297](https://github.com/martijnvanbrummelen/nwipe/pull/297)

v0.28
-----------------------
- Fixed premature exit when terminal resized on completion of wipes (Thanks PartialVolume)
- Fixed GUI when terminal is resized, currently not handled correctly causing missing or incorrectly sized ncurses windows/panels (Thanks PartialVolume)
- Fixed GUI screen flicker under various situations. [#200](https://github.com/martijnvanbrummelen/nwipe/pull/200) Fixes [#115](https://github.com/martijnvanbrummelen/nwipe/issues/115) (Thanks PartialVolume)
- Fixed responsivness of screen during wipe when resized. Info is updated every 10th/sec. Key presses are more responsive. (Thanks PartialVolume)
- Fixed compiler warning regarding buffer overflow. Fixes [#202](https://github.com/martijnvanbrummelen/nwipe/issues/202) (Thanks PartialVolume)
- Fixed Man page (Thanks martijnvanbrummelen)
- Fixed individual device throughput. On completion of a wipe instead of the throughput calculation stopping for a completed wipe, it would continue to calculate resulting in a particular drives throughtput slowly dropping until eventually it reached zero. The overall throughput was not affected. (Thanks PartialVolume)

v0.27
-----------------------
- Add `verify` method to verify a disk is zero filled [#128](https://github.com/martijnvanbrummelen/nwipe/pull/128) (Thanks Legogizmo)
- Add new HMG IS5 enhanced wipe method [#168](https://github.com/martijnvanbrummelen/nwipe/pull/168) (Thanks infrastation)
- Fixed percentage progress and show on completion of wipe (Thanks PartialVolume)
- Implement clang-format support (Thanks louib)
- Implement more frequent disk sync support (Thanks Legogizmo)
- Format command line help to 80 character line length [#114](https://github.com/martijnvanbrummelen/nwipe/pull/114) (Thanks PartialVolume)
- Fixed nwipe message log and missing messages that was causing segfaults under certain conditions (Thanks PartialVolume)
- Add the Github build CI service and update Readme with build status labels (Thanks louib)
- Miscellaneous smaller fixes

v0.26
-----
- Add exclude drive option (Thanks PartialVolume)
- Log hardware (Thanks PartialVolume)

v0.25
-----
- Correct J=Up K=Down in footer (Thanks PartialVolume)
- Fixed segfault initialize `nwipe_gui_thread` (Thanks PartialVolume)
- Fixed memory leaks (Thanks PartialVolume)
- Check right pointer (Thanks PartialVolume)
- Fixed casting problem (Thanks PartialVolume)
- Fixed serial number
- Fixed uninitialized variable warning (Thanks PartialVolume)

v0.24
-----
- use include values for version 0.17
- display throughput value more friendly (Thanks Kelderek)

v0.23
-----
- make serial visible again on 32Bit machines

v0.22
-----
- Update manpage
- use long long for device size
- Use `ped_unit_format_byte` function to display(friendly) size of device

v0.21
-----
- Fixed ETA not updating properly and bad total throughput display. (Thanks Niels Bassler).

v0.20
-----
- Fixed build when panel header is not in `/usr/include` (Thanks Vincent Untz).

v0.19
-----
- Fixed building on Fedora(Unknown `off64_t`) bug #19.
- Use PRNG instead of zero's bug #7. (Thanks xambroz).

v0.18
-----
- Fixed grammar.
- Move from `loff_t` to `off64_t` for musl libc support.
- Add `--nosignals` option.
- Automake needs the `dist_` prefix to include man pages in `make dist`.
- Remove more compiler warnings.
- Add libintl, libuuid dependencies to allow parted static link

v0.17
-----
- Remove control reaches end of non-void function" warnings (Thanks Vincent Untz).
- Remove unused variables (Thanks Vincent Untz).
- Change start key to 'S' instead of F10 (closes debian bug #755474).
- Fixed problem with unusable device (Closes debian bug #755473).

v0.16
-----
- Fixed problems building with clang compiler (Thanks Martijn van Brummelen)

v0.15
-----
- Add more detailed information to status page when wiping
- Add ability to send SIGUSR1 to print wiping current status to log
- Fixed problem with status bar disappearing on narrow windows (Github issue #1)

v0.14
-----
- Added explicit check for ncurses (required for Fedora). See bug 3604008.

v0.13
-----
- Added nowait option (patch 3601259 - thanks David Shaw).
- Added nogui option.
- Updated man page and help command for above options and autonuke.
- Added pkg-config check for ncurses (patch 3603140 - thanks Alon Bar-Lev).

v0.12
-----
- Added ability to specify device on command line (patch 3587144).
- Fixed segfault for -p option (patch 3587132).

v0.11
-----
- Fixed bug 3568750. Not closing devices after initial scan.

v0.10
-----
- Fixed bug 3553851. Not exiting on terminal kill. Fixed for all areas of
  program including wiping.

v0.09
-----
- Added feature #3545971. Display device name.
- Added feature #3496858. Option to not perform a final blanking pass.

v0.08
-----
- Fixed bug #3501746 whereby "wipe finished" was displayed too early

v0.07
-----
- Added threading synchronisation for logging
- Fixed bug #3486927 (incorrect Sourceforge URL)

v0.06
-----
- Added man page (thanks Michal Ambroz <rebus@seznam.cz>)
- Updated GPL licence and FSF address (thanks Michal Ambroz <rebus@seznam.cz>)

v0.05
-----
- Added sequence number to disk selection
- Added check for ncurses header files in subdir
- Fixed screen corruption bug introduced in 0.04
- Fixed occasional seg fault on start
- Introduced dynamic array allocation for devices, with no hard limit
- Minor updates to configure.ac

v0.04
-----
- Removed references to DBAN in options.c
- Added log file name option (-l|--logfile)
- If no log file specified all messages go to STDOUT
- Incorrect success message after an interruption fixed
- Improved labelling of disks with no partition table
- Added help command
- Added version command
- Added command 'b' to blank screen during wipe
- Compilation needs to include panel library

KNOWN BUG - display sometimes becomes corrupted after starting wipe

v0.03
-----
- Added quit option label (ctrl-c)
- Removed further references to DWIPE
- Added GPL V2 licence file (COPYING)

v0.02
-----
- Fixed segfault that happened during multiple disk wipes
